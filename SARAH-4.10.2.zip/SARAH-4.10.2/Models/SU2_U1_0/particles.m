ParticleDefinitions[GaugeES] = {
      {H0,  {    PDG -> {0},
                 Width -> 0, 
                 Mass -> Automatic,
                 FeynArtsNr -> 1,
                 LaTeX -> "H^0",
                 OutputName -> "H0" }},                         
      
      
      {Hp,  {    PDG -> {0},
                 Width -> 0, 
                 Mass -> Automatic,
                 FeynArtsNr -> 2,
                 LaTeX -> "H^+",
                 OutputName -> "Hp" }}, 
      {VWB,  { Description -> "W-Bosons"}},          
      {gWB,  { Description -> "W-Boson Ghost"}}      
      };
      
      
      
      
  ParticleDefinitions[EWSB] = {
            
      
    {hh   ,  {  Description -> "Radial Higgs Modes",
                 PDG -> {25,35},
                 PDG.IX -> {101000001,101000002},
				 LaTeX -> {"H_l","H_h"},
			 	 OutputName -> {"Hl","HH"} }}, 
                 
     {Ah   ,  {  Description -> "Pseudo-Scalar Higgs",
                 PDG -> {0},
                 PDG.IX ->{0},
                 Mass -> {0},
                 Width -> {0} }},                       
      
      
     {Hpm,     { Description -> "Charged Higgs/Pions", 
                 PDG -> {0,0},
                 PDG.IX ->{0,0},
                 Width -> {0,0}, 
                 Mass -> {0,0},
                 LaTeX -> {"H^+","H^-"},
                 OutputName -> {"Hp","Hm"}
                 }},                                                   
	  {VZ,   { Description -> "Z-Boson",
      			 Goldstone -> Ah }}, 
      {VWp,  { Description -> "W+ - Boson",
      			Goldstone -> Hpm[{1}] }},         
      {gWp,  { Description -> "Positive W+ - Boson Ghost"}}, 
      {gWpC, { Description -> "Negative W+ - Boson Ghost" }}, 
      {gZ,   { Description -> "Z-Boson Ghost" }}(*,
      {Fa,   { Description -> "a test fermion." }}*)                                                              
     
        };    
        
        
        
 WeylFermionAndIndermediate = {
     
    {H,      {   PDG -> {0},
                 Width -> 0, 
                 Mass -> Automatic,
                 LaTeX -> "H",
                 OutputName -> "" }},

   {aF,     {LaTeX -> "a_F" }}
};       


