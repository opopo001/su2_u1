Off[General::spell]

Model`Name = "SU2_U1_0";
Model`NameLaTeX ="SU2_U1_0_Model";
Model`Authors = "oleg";
Model`Date = "2017-05-12";

(*-------------------------------------------*)
(*   Particle Content*)
(*-------------------------------------------*)

(* Global Symmetries *)

Global[[1]] = {Z[2], Z2};
Global[[2]] = {Z[3], Z3};

(* Gauge Groups *)

Gauge[[1]]={WB, SU[2], left,g2,True,1,1};

(* Matter Fields *)

FermionFields[[1]] = {a,1,aR,1,-1,1};  
ScalarFields[[1]] =  {H,1,{Hp, H0},2,1,w};
ScalarFields[[2]] = {trip, 1, {{T0/Sqrt[2],conj[Tm]},{Tm,-T0/Sqrt[2]}},3,1,1};

RealScalars = {T0};

(*----------------------------------------------*)
(*   DEFINITION                                 *)
(*----------------------------------------------*)

NameOfStates={GaugeES, EWSB};

(* ----- Before EWSB ----- *)

DEFINITION[GaugeES][LagrangianInput]= {
	{LagNoHC,{AddHC->False}}
};
LagNoHC = -(-mu2 conj[H].H  - 1/2 MT trip.trip  + 1/2 LT  Delta[lef1b,lef2] Delta[lef2b,lef3] Delta[lef3b,lef4] Delta[lef4b,lef1] conj[trip].trip.conj[trip].trip \
 + mu3 conj[H].trip.H + 1/2 LH conj[H].H.conj[H].H + 1/2 LHT conj[H].H.conj[trip].trip)
	- mA a.a;
ContractionRGE[LT]=Delta[lef1,lef2] Delta[lef3, lef4];

(* Gauge Sector *)

DEFINITION[EWSB][GaugeSector] =
{ 
  {{VWB[3]},{VZ},ZZ},
  {{VWB[1],VWB[2]},{VWp,conj[VWp]},ZW}
};     
        
(* ----- VEVs ---- *)

DEFINITION[EWSB][VEVs]= 
	{     {H0, {v, 1/Sqrt[2]}, {Ah, \[ImaginaryI]/Sqrt[2]},{phiH, 1/Sqrt[2]}},
	      {T0, {vT, 1/Sqrt[2]}, {0, 0},{phiT, 1/Sqrt[2]}} }; 

DEFINITION[EWSB][MatterSector]=   
    {{{phiH,phiT},{hh,ZH}},
     {{Hp,conj[Tm]},{Hpm,ZP}}
     };  
	 
(*------------------------------------------------------*)
(* Dirac-Spinors *)
(*------------------------------------------------------*)

DEFINITION[EWSB][DiracSpinors]={
 Fa ->{  0, aR}};
