ParameterDefinitions = { 

	{g2,        { Description -> "Left-Coupling"}},
	{e,         { Description -> "electric charge"}}, 

	{Gf,        { Description -> "Fermi's constant"}},
	{aEWinv,    { Description -> "inverse weak coupling constant at mZ"}},


	{mu2,         { Description -> "SM Mu Parameter",
	        LesHouches -> {HMIX,2}}},                                        

	{LH,  { Description -> "SM Higgs Selfcouplings",
	               DependenceNum -> Mass[hh]^2/(v^2)},
	        LesHouches -> {HMIX,1} },

	{v,          { Description -> "EW-VEV",
	               DependenceNum -> Sqrt[4*Mass[VWp]^2/(g2^2)],
	               DependenceSPheno -> None  }},

	{vT,  { LaTeX -> "v_T",
	        Real -> True,
	        OutputName -> vT,
	        LesHouches -> {HMIX,20} }},

	{MT,  { LaTeX -> "\\mu_T",
	        OutputName -> MT,
	        LesHouches -> {HMIX,15} }},

	{mu3,  { LaTeX -> "\\kappa",
	        OutputName -> Kap,
	        LesHouches -> {HMIX,20} }},

	{LT,  { LaTeX -> "\\lambda_T",
	        OutputName -> LT,
	        LesHouches -> {HMIX,17} }},

	{LT2,  { LaTeX -> "{\\lambda'}_T",
	        OutputName -> LT2,
	        LesHouches -> {HMIX,18} }},        

	{LHT,  { LaTeX -> "\\lambda_{HT}",
	        OutputName -> LHT,
	        LesHouches -> {HMIX,19} }},        

	{ThetaW,    { Description -> "Weinberg-Angle",
	              DependenceNum -> ArcSin[Sqrt[1 - Mass[VWp]^2/Mass[VZ]^2]]}},


{mA,        { Description -> "a test filed Mass Parameter"}},

{ZH,  { Description->"Scalar-Mixing-Matrix",
        Real->True,
        LesHouches -> ZH,
        OutputName -> ZH,
        LaTeX->"Z^H", 
        Dependence -> None,
        DependenceOptional -> None,
        DependenceNum -> None}},

{ZP,        { Description->"Charged-Mixing-Matrix", 
                Dependence -> None,
               DependenceOptional -> None,
               DependenceNum -> None}}, 

{ZZ, {Description -> "Z Mixing Matrix",Dependence ->   1}},
{ZW, {Description -> "W Mixing Matrix",
       Dependence ->   1/Sqrt[2] {{1, 1},
                  {\[ImaginaryI],-\[ImaginaryI]}} }}
}; 
 

