Off[General::spell]

Model`Name = "SU2_U1_0";
Model`NameLaTeX ="SI Vector DM with Light Mediator";
Model`Authors = "Popov O., Kownacki C., Tanedo P.";
Model`Date = "2017-03-15";

(*-------------------------------------------*)
(*   Particle Content*)
(*-------------------------------------------*)

(* Gauge Groups *)

Gauge[[1]]={WDB, SU[2], dark,gD,True};

(* Matter Fields *)

ScalarFields[[1]] =  {H, 1, {Hu, Hd},2};
ScalarFields[[2]] =  {Phi, 1, {conj[phip], phip, phi3},3};

RealScalars = {phi0,HdR,HdI};

(*----------------------------------------------*)
(*   DEFINITION                                 *)
(*----------------------------------------------*)

NameOfStates={GaugeES, EWSB};

(* ----- Before EWSB ----- *)

DEFINITION[GaugeES][LagrangianInput]= {
	(*{LagHC, {AddHC->True}},*)
	{LagNoHC,{AddHC->False}}
};

LagNoHC =mu2H conj[H].H - 1/2 \[Lambda]H conj[H].H.conj[H].H + 1/2 mu2Phi conj[Phi].Phi - 1/4 \[Lambda]phi conj[Phi].Phi.conj[Phi].Phi-\[Lambda]Hphi conj[H].H.conj[Phi].Phi-mu3 conj[H].Phi2x2.H;
(*LagHC = -mu4 conj[H].Phi2x2.(\[ImaginaryI] PauliMatrix[2].conj[H]);*)

(* Gauge Sector *)

DEFINITION[EWSB][GaugeSector] =
{ 
  {{VWDB[3]},{VPD},ZPD}, 
  {{VWDB[1],VWDB[2]},{VWDp,conj[VWDp]},ZWD}
};     

(* ----- VEVs ---- *)

DEFINITION[EWSB][VEVs]= 
{    {Hd, {v, 1/Sqrt[2]}, {HdI, \[ImaginaryI]/Sqrt[2]},{HdR, 1/Sqrt[2]}},
	 {phi3, {u, 1}, {0, 0},{phi0, 1}}
};

DEFINITION[EWSB][MatterSector]=   
    {
	{{HuR,phi1},{SuR1,UuR1}},
	{{HdR,phi0},{SdR0,UdR0}},
	{{HuI,phi2},{SuI2,UuI2}}
	};

(*------------------------------------------------------*)
(* Dirac-Spinors *)
(*------------------------------------------------------*)

DEFINITION[EWSB][DiracSpinors]={
};

DEFINITION[EWSB][GaugeES]={
};