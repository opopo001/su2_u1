------------------------------------------------------------------------------------
This directory contains results stored and retrievable with the function CheckDB.
This directory serves as cache area, i.e. the results stored here are regenerable.
The results are typically integrals and amplitudes calculated with FeynCalc.
------------------------------------------------------------------------------------
